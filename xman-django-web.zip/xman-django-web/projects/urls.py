from django.urls import path, include
from . import views

urlpatterns = [
    path('projects/', views.projects, name='projects'),
     path('includes/', views.results, name='results'),
    path('dashboard/', views.dashboard, name='dashboard'),
    ]